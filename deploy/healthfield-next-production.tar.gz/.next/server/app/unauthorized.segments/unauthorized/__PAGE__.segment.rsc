1:"$Sreact.fragment"
2:I[2923,[],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"unauthorized","children":["$","div",null,{"children":[["$","span",null,{"children":"403"}],["$","h1",null,{"children":"Access restricted"}],["$","p",null,{"children":"Your account does not have permission to open this area."}],["$","a",null,{"href":"/","children":"Return to Healthfield"}]]}]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"zBIrN7S96bfH0weYNDkWy"}
4:null
