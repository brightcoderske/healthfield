1:"$Sreact.fragment"
2:I[9426,[],""]
3:I[2464,[],""]
:HL["/_next/static/css/d7e8310cb33187fe.css","style"]
:HL["/_next/static/css/f4f648d31889c528.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/d7e8310cb33187fe.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/f4f648d31889c528.css","precedence":"next"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"__variable_246ccd","children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"xEekf2vpnVBEB2EKrFGW4"}
