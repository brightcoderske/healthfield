1:"$Sreact.fragment"
2:I[9426,[],""]
3:I[2464,[],""]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"xEekf2vpnVBEB2EKrFGW4"}
