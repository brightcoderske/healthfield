1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[8316,["4432","static/chunks/4432-b144c71b74078651.js","4520","static/chunks/app/login/page-933d1584f3f00987.js"],"LoginForm"]
4:I[2923,[],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","main",null,{"className":"auth-page"}],"children":["$","$L3",null,{}]}],null,["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"zBIrN7S96bfH0weYNDkWy"}
5:null
