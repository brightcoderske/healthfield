1:"$Sreact.fragment"
2:I[2923,[],"ViewportBoundary"]
3:I[2923,[],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[9938,[],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Sign in | Healthfield Pharmacy"}],["$","meta","1",{"name":"description","content":"Shop medicines, skincare, wellness and personal-care products from Healthfield Pharmacy."}],["$","link","2",{"rel":"manifest","href":"/manifest.webmanifest"}],["$","link","3",{"rel":"icon","href":"/healthfield-icon.png"}],["$","link","4",{"rel":"apple-touch-icon","href":"/healthfield-icon.png"}],["$","$L5","5",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"HnbLKEszYzbZuCwrfDJD3"}
